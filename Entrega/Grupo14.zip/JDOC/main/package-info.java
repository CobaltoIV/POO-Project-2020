/**
 * This package onl contains the main of the project
 */
package main;